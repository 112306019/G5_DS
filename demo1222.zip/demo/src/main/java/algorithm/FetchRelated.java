package algorithm;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class FetchRelated {
    private String content;

    public FetchRelated(String content) {
        this.content = content;
    }

    public List<String> fetchRelatedKeywords() {
        List<String> relatedKeywords = new ArrayList<>();
        try {
            Document doc = Jsoup.parse(content);

            // Select elements in the "Related searches" section
            Elements relatedElements = doc.select("div.s75CSd a");

            for (Element relatedElement : relatedElements) {
                String keyword = relatedElement.text();
                if (!keyword.isEmpty()) {
                    relatedKeywords.add(keyword);
                }
            }

        } catch (Exception e) {
            System.err.println("Error fetching related keywords: " + e.getMessage());
        }
        return relatedKeywords;
    }
}
